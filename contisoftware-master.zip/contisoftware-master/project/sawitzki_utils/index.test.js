let util = require('./index')
describe("test utilities", () => {
    test("area of rectangle with height = 2 and width = 3 is 6", () => {
        expect(util.rectangleArea(2, 3)).toBe(6)
    })
    test("perimeter of rectangle with height = 2 and width = 3 is 10", () => {
        expect(util.rectanglePerimeter(2, 3)).toBe(10)
    })
    test("perimeter of circle with radius 1 is 6.283185", () => {
        expect(util.circlePerimeter(1)).toBeCloseTo(6.283185)
    })
    test("area of circle with radius 1 is 3.141592", () => {
        expect(util.circleArea(1)).toBeCloseTo(3.141592)
    })

})