function rectangleArea(height, width){
	let result = height * width
	return result
}
function rectanglePerimeter(height, width){
	let result = 2* (height + width)
	return result
}

function circleArea(radius){
	let result = radius * radius * Math.PI
	return result
}
function circlePerimeter(radius){
	let result = 2* radius * Math.PI
	return result
}


exports.rectangleArea = rectangleArea
exports.rectanglePerimeter = rectanglePerimeter
exports.circleArea = circleArea
exports.circlePerimeter = circlePerimeter