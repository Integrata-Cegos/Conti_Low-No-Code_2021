let names = ["Hugo", "Emil", "Zvonimir", "Fritz", "Egon"]
exports.names = names
exports.namesWithE = Array.from(names.filter((name) => name.charAt(0) === 'E'))
exports.namesWith4Letters = Array.from(names.filter((name) => name.length === 4))
exports.nameLength = Array.from(names.map((name) => name.length))
exports.sortedLexically = Array.from(names.sort())
exports.sortedByLength = Array.from(names.sort((name1, name2) => name1.length - name2.length))
