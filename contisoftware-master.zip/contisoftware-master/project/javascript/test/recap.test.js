let data = require('../impl/recap')
describe("test recap", () => {
    test("expect names has 5 elements", () => {
        expect(data.names.length).toBe(5)
    })
    test("expect names starting with E has 2 elements", () => {
        expect(data.namesWithE.length).toBe(2)
    })

    test("expect names having 4 letters has 3 elements", () => {
        expect(data.namesWith4Letters.length).toBe(3)
    })
    test('expect lexically sorted names to be ["Egon", "Emil", "Fritz", "Hugo", "Zvonimir"]', () => {
        expect(data.sortedLexically).toStrictEqual(["Egon", "Emil", "Fritz", "Hugo", "Zvonimir"])
    })
    test('expect fifth element of names sorted by length to be Zvonimir', () => {
        expect(data.sortedByLength[4]).toBe("Zvonimir")
    })

    test('expect fourth element of names sorted by length to be Zvonimir', () => {
        expect(data.sortedByLength[3]).toBe("Fritz")
    })

})